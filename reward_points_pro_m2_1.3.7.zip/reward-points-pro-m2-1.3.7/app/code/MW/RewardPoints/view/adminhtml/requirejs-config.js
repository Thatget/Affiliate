var config = {
    map: {
        '*': {
            mwValidate: 'MW_RewardPoints/js/validate',
            mwHeadMain: 'MW_RewardPoints/js/head.main',
            mwHighcharts: 'MW_RewardPoints/js/lib/highcharts',
            mwExporting: 'MW_RewardPoints/js/lib/exporting',
            mwAdapter: 'MW_RewardPoints/js/lib/prototype-adapter',
            mwAccordion: 'MW_RewardPoints/js/accordion'
        }
    }
};
