var config = {
    map: {
        '*': {
            mwRewardSlider: 'MW_RewardPoints/js/mw.reward.slider',
            mwPopup: 'MW_RewardPoints/js/mw_popup',
            mwTransaction: 'MW_RewardPoints/js/transaction',
            mwSlideShow: 'MW_RewardPoints/js/slideshow',
            mwEarnRewardpoints: 'MW_RewardPoints/js/view/checkout/summary/earn-rewardpoints',
            mwRedeemRewardpoints: 'MW_RewardPoints/js/view/checkout/summary/redeem-rewardpoints'
        }
    }
};
