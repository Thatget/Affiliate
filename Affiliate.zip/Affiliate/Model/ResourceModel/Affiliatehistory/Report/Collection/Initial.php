<?php

namespace MW\Affiliate\Model\ResourceModel\Affiliatehistory\Report\Collection;

class Initial extends \Magento\Reports\Model\ResourceModel\Report\Collection
{
    /**
     * Report sub-collection class name
     *
     * @var string
     */
    protected $_reportCollection = 'MW\Affiliate\Model\ResourceModel\Affiliatehistory\Report\Collection';
}
