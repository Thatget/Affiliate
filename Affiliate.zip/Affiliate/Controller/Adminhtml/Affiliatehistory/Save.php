<?php

namespace MW\Affiliate\Controller\Adminhtml\Affiliatehistory;

class Save extends \MW\Affiliate\Controller\Adminhtml\Affiliatehistory
{
    /**
     * Import transactions save action
     * TODO: Must to re-check
     */
    public function execute()
    {

    }
}
