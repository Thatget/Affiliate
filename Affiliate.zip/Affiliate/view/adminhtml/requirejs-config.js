var config = {
    map: {
        '*': {
            mwEffects: 'MW_Affiliate/js/scriptaculous/effects',
            mwAutocompleter: 'MW_Affiliate/js/scriptaculous/controls',
            mwHeadMain: 'MW_Affiliate/js/head.main',
            mwHighcharts: 'MW_Affiliate/js/lib/highcharts',
            mwExporting: 'MW_Affiliate/js/lib/exporting',
            mwAdapter: 'MW_Affiliate/js/lib/prototype-adapter'
        }
    }
};
